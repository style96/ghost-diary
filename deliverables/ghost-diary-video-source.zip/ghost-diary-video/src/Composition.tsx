import React from 'react';
import {AbsoluteFill,CanvasImage,Composition,interpolate,Sequence,staticFile,useCurrentFrame,useVideoConfig} from 'remotion';
import {Video} from '@remotion/media';
import {Narration} from './Narration';

const paper='#f4efe2',olive='#292e26',rust='#985e4e';
const serif='Georgia, "Times New Roman", serif',sans='Arial, Helvetica, sans-serif';
const clamp={extrapolateLeft:'clamp' as const,extrapolateRight:'clamp' as const};
const shot:React.CSSProperties={width:'100%',height:'100%',objectFit:'cover'};
const Chapter=({number,title,note='ACTUAL LOCAL APP'}:{number:string;title:string;note?:string})=><div style={{position:'absolute',left:100,right:100,top:46,display:'flex',justifyContent:'space-between',alignItems:'center',color:paper,fontFamily:sans}}><div style={{fontSize:27,letterSpacing:1}}><span style={{color:'#d1b399',marginRight:22,fontSize:21}}>{number}</span>{title}</div><div style={{fontSize:18,letterSpacing:3,color:'#b4b69f'}}>{note}</div></div>;
const Screen=({children}:{children:React.ReactNode})=><div style={{position:'absolute',left:125,top:120,width:1670,height:940,overflow:'hidden',borderRadius:13,boxShadow:'0 25px 85px #0005',border:'1px solid #e8dfc840',background:paper}}>{children}</div>;
const Ghost=()=> <svg width="64" height="77" viewBox="0 0 60 72" fill="none"><path d="M10 60V28a20 20 0 0140 0v32l-10-6-10 6-10-6-10 6z" fill="currentColor"/><ellipse cx="23" cy="28" rx="2.7" ry="4.4" fill={olive}/><ellipse cx="37" cy="28" rx="2.7" ry="4.4" fill={olive}/></svg>;

const Bookend=({closing=false}:{closing?:boolean})=>{
  const frame=useCurrentFrame();const {fps}=useVideoConfig();
  return <AbsoluteFill style={{background:olive}}>
    <CanvasImage src={staticFile('hero.png')} style={{...shot,scale:interpolate(frame,[0,(closing?9:7)*fps],closing?[1.04,1]:[1,1.04],clamp)}}/>
    <AbsoluteFill style={{background:'linear-gradient(90deg,#172019bb 0%,#17201944 58%,transparent 85%)'}}/>
    <div style={{position:'absolute',left:105,top:closing?165:245,color:paper,width:900,opacity:interpolate(frame,[0,22],[0,1],clamp),translate:`0 ${interpolate(frame,[0,30],[24,0],clamp)}px`}}>
      <div style={{fontFamily:sans,fontSize:22,letterSpacing:5,color:'#dfd7bc',marginBottom:34}}>{closing?'GHOST DIARY':'A NOTEBOOK WITH A PRESENCE'}</div>
      {closing?<div style={{fontFamily:serif,fontSize:105,lineHeight:1.08,letterSpacing:-4}}>Your words.<br/><em>Until they're not.</em></div>:<><div style={{fontFamily:serif,fontSize:142,letterSpacing:-6,lineHeight:1.04}}>Ghost Diary.</div><div style={{fontFamily:serif,fontSize:50,fontStyle:'italic',marginTop:34,color:'#e2d6bb'}}>Your words. Until they're not.</div></>}
      <div style={{fontFamily:sans,fontSize:closing?30:21,letterSpacing:closing?0:2,color:'#e1dbc4',marginTop:48}}>{closing?'github.com/style96/ghost-diary':'A REAL LOCAL-APP DEMONSTRATION'}</div>
      {closing&&<div style={{fontFamily:sans,fontSize:22,color:'#c3c7ae',marginTop:22}}>Explore the recorded demo. Run your own ghost locally.</div>}
    </div>
    {closing&&<><div style={{position:'absolute',left:105,bottom:180,color:'#d3cfb8',fontFamily:sans,fontSize:18,lineHeight:1.7}}>DIARY AI: GEMMA · APP SPEECH: WINDOWS<br/>NARRATION: ELEVENLABS · ILLUSTRATION: IMAGEGEN</div><AbsoluteFill style={{background:olive,opacity:interpolate(frame,[8.55*fps,9*fps],[0,1],clamp)}}/></>}
  </AbsoluteFill>;
};

const Writing=()=>{const {fps}=useVideoConfig();return <AbsoluteFill style={{background:olive}}>
  <Chapter number="01" title="Leave your words"/>
  <Screen><CanvasImage src={staticFile('restored.png')} style={shot}/><Sequence name="Actual typing and saving" durationInFrames={15.3*fps}><Video src={staticFile('captures/01-writing.mp4')} muted playbackRate={.55} style={shot}/></Sequence></Screen>
</AbsoluteFill>};

const Haunting=()=>{const {fps}=useVideoConfig();return <AbsoluteFill style={{background:olive}}>
  <Chapter number="02" title="Let the night pass" note="REAL GEMMA OUTPUT · WAIT SHORTENED"/>
  <Screen>
    <CanvasImage src={staticFile('haunted.png')} style={shot}/>
    <Sequence name="Click and real generation wait" durationInFrames={4.67*fps}><Video src={staticFile('captures/02-haunting.mp4')} muted style={shot}/></Sequence>
    <Sequence name="Real generation, continued" from={4.67*fps} durationInFrames={8.81*fps}><Video src={staticFile('captures/02b-haunting.mp4')} muted style={shot}/></Sequence>
    <Sequence name="Actual completed generation" from={13.48*fps} durationInFrames={3.52*fps}><Video src={staticFile('captures/02c-haunting.mp4')} muted style={shot}/></Sequence>
  </Screen>
</AbsoluteFill>};

const Reveal=()=>{const frame=useCurrentFrame();const {fps}=useVideoConfig();return <AbsoluteFill style={{background:paper,color:'#333a2e'}}>
  <div style={{position:'absolute',left:100,top:75,fontFamily:sans,fontSize:22,letterSpacing:4,color:rust}}>THE LINE I DIDN'T WRITE</div>
  <div style={{position:'absolute',left:100,top:220,width:700,opacity:interpolate(frame,[0,.6*fps],[0,1],clamp),translate:`0 ${interpolate(frame,[0,.8*fps],[20,0],clamp)}px`}}>
    <div style={{fontFamily:serif,fontSize:77,lineHeight:1.14,letterSpacing:-2.3,color:rust}}>“I traced the<br/>bent spoke with<br/>my finger.”</div>
    <div style={{height:1,background:'#b1ad974d',width:590,marginTop:48,marginBottom:28}}/>
    <div style={{fontFamily:sans,fontSize:24,lineHeight:1.6,color:'#737967'}}>A detail from the previous page.<br/>A new sentence from Gemma.</div>
    <div style={{fontFamily:sans,fontSize:19,letterSpacing:2,color:rust,marginTop:38}}>{frame>=7.85*fps&&frame<12.55*fps?'LISTEN · LOCAL WINDOWS VOICE':'ACTUAL GENERATED TEXT'}</div>
  </div>
  <div style={{position:'absolute',left:850,top:170,width:960,height:690,overflow:'hidden',borderRadius:14,boxShadow:'0 20px 60px #232c2620',border:'1px solid #d8d0ba'}}>
    <CanvasImage src={staticFile('haunted.png')} style={{...shot,objectPosition:'right center'}}/>
    <Sequence name="Actual local speech playback capture" from={5.45*fps} durationInFrames={8.05*fps}><Video src={staticFile('captures/03-voice.mp4')} muted style={{...shot,objectPosition:'right center'}}/></Sequence>
  </div>
  <div style={{position:'absolute',left:850,top:890,color:'#777e6a',fontFamily:sans,fontSize:20,letterSpacing:1}}>RECORDED LIVE · localhost:3001 · gemma3:4b</div>
</AbsoluteFill>};

const Comparison=()=>{const {fps}=useVideoConfig();return <AbsoluteFill style={{background:olive}}>
  <Chapter number="03" title="Your original is still yours"/>
  <Screen>
    <CanvasImage src={staticFile('comparison.png')} style={shot}/>
    <Sequence name="Open original-versus-ghost comparison" durationInFrames={7.6*fps}><Video src={staticFile('captures/04-comparison.mp4')} muted playbackRate={.6} style={shot}/></Sequence>
    <Sequence name="Restore the actual original" from={8*fps} durationInFrames={4.4*fps}><Video src={staticFile('captures/05-restore.mp4')} muted style={shot}/></Sequence>
    <Sequence name="Restored original held for reading" from={12.4*fps}><CanvasImage src={staticFile('restored.png')} style={shot}/></Sequence>
  </Screen>
</AbsoluteFill>};

const FlowNode=({label,detail,x,from}:{label:string;detail:string;x:number;from:number})=>{const frame=useCurrentFrame();const {fps}=useVideoConfig();return <div style={{position:'absolute',left:x,top:390,width:450,height:230,border:'1px solid #cfc4ab',borderRadius:18,background:'#fbf8ed',padding:'52px 38px',boxSizing:'border-box',opacity:interpolate(frame,[from*fps,(from+.5)*fps],[0,1],clamp),translate:`0 ${interpolate(frame,[from*fps,(from+.5)*fps],[18,0],clamp)}px`}}><div style={{fontFamily:serif,fontSize:48,letterSpacing:-1}}>{label}</div><div style={{fontFamily:sans,fontSize:22,color:'#7a816f',marginTop:20}}>{detail}</div></div>};

const LocalDiagram=()=>{const frame=useCurrentFrame();const {fps}=useVideoConfig();return <AbsoluteFill style={{background:paper,color:'#333a2e'}}>
  <div style={{position:'absolute',left:110,top:95,fontFamily:sans,fontSize:21,letterSpacing:5,color:rust}}>A GHOST YOU CAN LOOK INSIDE</div>
  <div style={{position:'absolute',left:110,top:170,fontFamily:serif,fontSize:92,letterSpacing:-3}}>The diary stays with you.</div>
  <div style={{position:'absolute',left:111,top:298,fontFamily:sans,fontSize:28,color:'#7c826f'}}>Browser storage. Local inference. Original words preserved.</div>
  <FlowNode label="Your notebook" detail="Stored in your browser" x={110} from={.5}/><FlowNode label="Local server" detail="Loopback connection" x={735} from={1.8}/><FlowNode label="Ollama + Gemma" detail="Writes the small intervention" x={1360} from={3.1}/>
  <div style={{position:'absolute',left:594,top:464,fontSize:58,color:rust,opacity:interpolate(frame,[1.6*fps,2*fps],[0,1],clamp)}}>→</div><div style={{position:'absolute',left:1218,top:464,fontSize:58,color:rust,opacity:interpolate(frame,[2.9*fps,3.3*fps],[0,1],clamp)}}>→</div>
  <div style={{position:'absolute',left:110,top:720,display:'flex',alignItems:'center',gap:32,color:'#66705c',opacity:interpolate(frame,[6*fps,6.6*fps],[0,1],clamp)}}><Ghost/><div><div style={{fontFamily:serif,fontSize:40}}>The ghost has a local voice, too.</div><div style={{fontFamily:sans,fontSize:23,marginTop:14}}>Windows desktop speech · only after you press play</div></div></div>
</AbsoluteFill>};

export const GhostDiaryFilm=({audioEnabled=true}:{audioEnabled?:boolean})=>{const {fps}=useVideoConfig();return <AbsoluteFill style={{background:olive,fontFamily:sans}}>
  <Sequence name="Opening illustration" durationInFrames={7*fps}><Bookend/></Sequence>
  <Sequence name="01 Write and save a real entry" from={7*fps} durationInFrames={16*fps}><Writing/></Sequence>
  <Sequence name="02 Actual local Gemma generation" from={23*fps} durationInFrames={17*fps}><Haunting/></Sequence>
  <Sequence name="Real ghost line and local speech" from={40*fps} durationInFrames={14*fps}><Reveal/></Sequence>
  <Sequence name="03 Compare and restore" from={54*fps} durationInFrames={14*fps}><Comparison/></Sequence>
  <Sequence name="Local architecture" from={68*fps} durationInFrames={13*fps}><LocalDiagram/></Sequence>
  <Sequence name="Closing and credits" from={81*fps} durationInFrames={9*fps}><Bookend closing/></Sequence>
  <Narration audioEnabled={audioEnabled}/>
</AbsoluteFill>};
export const MyComposition=()=> <Composition id="GhostDiaryDemo" component={GhostDiaryFilm} defaultProps={{audioEnabled:true}} durationInFrames={2700} fps={30} width={1920} height={1080}/>;
