"""Mix approved narration and actual local speech, then mux the rendered picture."""
from pathlib import Path
import argparse,json,subprocess,shutil
parser=argparse.ArgumentParser()
parser.add_argument('--ffmpeg',default='ffmpeg')
parser.add_argument('--audio-only',action='store_true')
parser.add_argument('--output',default='render/ghost-diary-demo.mp4')
args=parser.parse_args()
project=Path(__file__).resolve().parent
public=project/'public';render=project/'render';render.mkdir(exist_ok=True)
scenes=json.loads((public/'narration-timings.json').read_text())
segments=[{'path':public/'narration'/f"{s['id']}.mp3",'start':s['start'],'end':s['end'],'gain':1} for s in scenes]
segments.append({'path':public/'ghost-voice.wav','start':47.85,'end':52.454127,'gain':1.15})
ordered=sorted(segments,key=lambda s:s['start'])
for previous,current in zip(ordered,ordered[1:]):
    if previous['end']>current['start']:raise ValueError('Voice segments overlap')
command=[args.ffmpeg,'-hide_banner','-y']
for segment in segments:command+=['-i',str(segment['path'])]
filters=[]
for i,segment in enumerate(segments):
    delay=round(segment['start']*1000)
    filters.append(f"[{i}:a]aformat=sample_rates=48000:channel_layouts=stereo,volume={segment['gain']},adelay={delay}|{delay}[a{i}]")
filters.append(''.join(f'[a{i}]' for i in range(len(segments)))+'amix=inputs=8:normalize=0:duration=longest,apad,atrim=duration=90,loudnorm=I=-16:TP=-1.5:LRA=11:print_format=json[mix]')
command+=['-filter_complex',';'.join(filters),'-map','[mix]','-ar','48000','-c:a','pcm_s24le',str(render/'master.wav')]
result=subprocess.run(command,check=True,capture_output=True,text=True)
(render/'audio-mix-log.txt').write_text(result.stderr,encoding='utf-8')
print('90-second audio master written; no overlapping speech or background soundtrack.',flush=True)
if args.audio_only:raise SystemExit(0)
output=Path(args.output).resolve();output.parent.mkdir(parents=True,exist_ok=True)
subprocess.run([args.ffmpeg,'-hide_banner','-loglevel','error','-y','-i',str(render/'ghost-diary-silent.mp4'),'-i',str(render/'master.wav'),'-map','0:v:0','-map','1:a:0','-c:v','copy','-c:a','aac','-b:a','192k','-ar','48000','-t','90','-movflags','+faststart',str(output)],check=True)
shutil.copy2(public/'ghost-diary-demo.en.srt',output.with_suffix('.en.srt'))
shutil.copy2(project/'review/poster.png',output.with_suffix('.poster.png'))
print(json.dumps({'video':str(output),'bytes':output.stat().st_size,'duration':90,'captions':str(output.with_suffix('.en.srt'))},indent=2))
