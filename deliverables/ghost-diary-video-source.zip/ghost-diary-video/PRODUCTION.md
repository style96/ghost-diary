# Ghost Diary — 90-second local-app demo

1920×1080, 30 fps. Narration: English, ElevenLabs Sarah / eleven_v4.
Actual application speech: captured Windows desktop speech WAV. No soundtrack.
Opening/closing artwork: ImageGen. Diagram and titles: editable Remotion React.

All diary content shown is fictional. Captured at localhost:3001 in a clean
origin with two deliberately authored test entries. Real model output:
“I traced the bent spoke with my finger.” The bent spoke occurs only in the
earlier fictional page. `public/diary-evidence.json` preserves original and
generated text; `public/events.json` preserves observed capture timings.
The comparison and restore operations were performed in the real application.

Raw UI footage was sampled continuously from the real browser viewport as
timestamped screenshots (roughly 7–8 captured frames/second), then encoded at
30 fps with held frames. This is not native 30 fps screen acquisition. Typing
is slowed for readability. The inference wait is shortened and labeled on screen.
The source captures are not fabricated app recreations. Keep the evidence label
when re-editing. The notebook is restored at the end of the demonstration.

## Edit and export

```sh
npm ci
npx remotion studio
```

Composition: `GhostDiaryDemo`. The interactive preview has audio enabled.
`src/Narration.tsx` contains word-aligned captions and independently positioned
narration clips. Corresponding provider character alignments and generation
metadata are saved beside each MP3 in `public/narration/`; no key is included.
`src/basic-captions.tsx` is the unchanged official Remotion Basic Captions element.

Windows inline audio mixing encountered a renderer error during production.
The reliable export separates picture and sound:

```sh
npx remotion render GhostDiaryDemo render/ghost-diary-silent.mp4 --props=render-props.json --muted --concurrency=2 --crf=18 --pixel-format=yuv420p
python finish.py --ffmpeg /path/to/ffmpeg --output render/ghost-diary-demo.mp4
```

`finish.py` needs Python 3 and FFmpeg; no Python packages or credentials are needed.
It verifies that speech segments do not overlap, creates a 90-second stereo
master normalized to -16 LUFS / -1.5 dBTP, then muxes H.264 picture with AAC audio.
The `.en.srt` captions and `.poster.png` cover are copied alongside the MP4.

No video was published to any external service as part of this production.
